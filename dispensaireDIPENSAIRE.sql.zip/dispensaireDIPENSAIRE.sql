-- phpMyAdmin SQL Dump
-- version 2.11.2.1
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Sam 28 Mars 2020 à 22:47
-- Version du serveur: 5.0.45
-- Version de PHP: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Base de données: `dispensaire`
--

-- --------------------------------------------------------

--
-- Structure de la table `identification`
--

CREATE TABLE `identification` (
  `Fonction` varchar(50) NOT NULL,
  `MDP` varchar(50) NOT NULL,
  PRIMARY KEY  (`MDP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `identification`
--

INSERT INTO `identification` (`Fonction`, `MDP`) VALUES
('Administrateur', ' Admin1'),
('Infirmier', ' Infi1'),
('Laborantin', ' Labo1'),
('Medecin', ' Medec1'),
('Pharmacien', ' Pharma1');

-- --------------------------------------------------------

--
-- Structure de la table `laboratoire`
--

CREATE TABLE `laboratoire` (
  `Num_pa` varchar(50) NOT NULL,
  `Id_labo` varchar(50) NOT NULL,
  `Note_Tech` varchar(50) NOT NULL,
  PRIMARY KEY  (`Id_labo`),
  KEY `fk_nu_patients` (`Num_pa`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `laboratoire`
--

INSERT INTO `laboratoire` (`Num_pa`, `Id_labo`, `Note_Tech`) VALUES
('69647997', '69647997', 'aucun examen .prenez juste les medicaments dans l\\');

-- --------------------------------------------------------

--
-- Structure de la table `patients`
--

CREATE TABLE `patients` (
  `Noms_pa` varchar(200) NOT NULL,
  `Prenoms_pa` varchar(200) NOT NULL,
  `Ages` varchar(20) NOT NULL,
  `Quartiers` varchar(200) NOT NULL,
  `Professions` varchar(200) NOT NULL,
  `Contacts` varchar(50) NOT NULL,
  `Temperatures` int(50) NOT NULL,
  `Poids` int(50) NOT NULL,
  `Tailles` int(50) NOT NULL,
  `Tensions` int(50) NOT NULL,
  `Note_Dr` varchar(500) NOT NULL,
  `Ordonnance` varchar(500) NOT NULL,
  PRIMARY KEY  (`Contacts`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `patients`
--

INSERT INTO `patients` (`Noms_pa`, `Prenoms_pa`, `Ages`, `Quartiers`, `Professions`, `Contacts`, `Temperatures`, `Poids`, `Tailles`, `Tensions`, `Note_Dr`, `Ordonnance`) VALUES
('TJADE II', 'jeannot', '5', 'DOMAYO', 'ENSEIGNANT', '69647994', 14, 16, 28, 12, 'vous avez la diarhÃ©e', 'hubufjl'),
('NGANDO', 'FRANK', '10', 'DOMAYO', 'ENSEIGNANT', '69647997', 46, 101, 100, 12, '', '');

-- --------------------------------------------------------

--
-- Structure de la table `personnels`
--

CREATE TABLE `personnels` (
  `Noms` varchar(500) NOT NULL,
  `Prenoms` varchar(200) NOT NULL,
  `Matricules` varchar(50) NOT NULL,
  `Fonctions` varchar(50) NOT NULL,
  PRIMARY KEY  (`Matricules`),
  UNIQUE KEY `Matricules` (`Matricules`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `personnels`
--

INSERT INTO `personnels` (`Noms`, `Prenoms`, `Matricules`, `Fonctions`) VALUES
('TJADE II', 'JEANNOT', '16A0416N', 'URGENTISTE');

-- --------------------------------------------------------

--
-- Structure de la table `pharmacie_stock`
--

CREATE TABLE `pharmacie_stock` (
  `Noms_medoc` varchar(200) NOT NULL,
  `Prix_medoc` int(10) NOT NULL,
  `Code_IBSN` int(20) NOT NULL,
  PRIMARY KEY  (`Code_IBSN`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `pharmacie_stock`
--

INSERT INTO `pharmacie_stock` (`Noms_medoc`, `Prix_medoc`, `Code_IBSN`) VALUES
('Paracetamol', 500, 1267890376),
('CHLOROQUINE', 15000, 2147483647);

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `laboratoire`
--
ALTER TABLE `laboratoire`
  ADD CONSTRAINT `fk_nu_patients` FOREIGN KEY (`Num_pa`) REFERENCES `patients` (`Contacts`);
